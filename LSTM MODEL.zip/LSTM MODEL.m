% @================> Time Series Prediction <==================@
 %Deep learning Bi-Long Short Memory (bi-LSTM) Network



%%
clc; clear; close all;
% General Parameters 
opt.Delays = [1 2 3 4 5 6 12 16 18 20 24]; % input delay, [1] , [3 6 9] ...   
opt.trPercentage    = 0.8;                 % divide data in Test and Train parts.
opt.isNormilizeData = true;                % if 'true' it allows code to normalize input data else if 'false' it doesn�t normalize input data.
opt.learningMethod  = 'DeepLearning';      % 'ShallowLearning'  'DeepLearning'.choose which method evaluate the time series.
opt.isUseDelays     = true;                % 'true' 'false'. if it set on false, automatically opt.Delays set on one delay ("[1]") it means network could predict one step ahead only with one lag.

% Bi-LSTM parameters
opt.numHiddenUnits1 = 250;                       % count of hidden layers in bi-LSTM unit One.
opt.numHiddenUnits2 = 250;                       % count of hidden layers in bi-LSTM unit Two.
opt.maxEpochs       = 200;                      % maximum number of training Epoch in bi-LSTM.
opt.miniBatchSize   = 120;                       % minimum batch size in bi-LSTM .
opt.executionEnvironment = 'cpu';                % 'cpu', 'gpu'. Training bi-LSTM network supports single CPU and GPU training only, and its fastter with CPU !!!  
opt.trainingProgress     = 'training-progress';  % 'training-progress' 'none'.

% feedforward parameters
opt.ShallowhiddenLayerSize = [30 50];        % number of Hidden layers in feedforward network.
opt.trainFcn               = 'trainbr';      % 'trainbr' 'trainlm'.
opt.maxItrations           =500;           % maximum number of training iteration in feedforward network.
opt.showWindow             = true;           % display training window.
opt.showCommandLine        = false;          % display training process on workspace.
%%
tic;
% input your excel file 
data = readInputExcelFile;

if ~data.isDataRead
    return;
end

% eliminate NaN with mean value of column and normalize data 
data = dataPreparation(data,opt);

% divide data into test and train data
data = dataPartitioning(data,opt);

% prepare delay for time serie network
data = CreateTimeSeriesData(data,opt);
if strcmpi(opt.learningMethod,'DeepLearning')
    % LSTM data form
    data = LSTMInput(data);
    %  Define LSTM  architect 
    opt = LSTMArchitect(opt);
elseif strcmpi(opt.learningMethod,'ShallowLearning')
    % Prepare input data for FeedForward network.
    data = FeedForwardInput(data);
    %  Define feedforward architect 
    opt  = FeedForwardArchitect(opt);   
end

% Train LSTM or FeedForward Network
results.Net = TrainNet(data,opt);

% evaluate the network output
results = evaluateNet(results,data,opt);

totalTime = toc;
disp(['Total Computational time is: ' num2str(totalTime)]);
disp('Operation Successfully finished.');

%% -------------------> Local Functions <-----------------------

%  ---- data preparation ----
% Read input time series excel file
function data = readInputExcelFile
[chosenfile,chosendirectory] = uigetfile({'*.xlsx';'*.csv'},...
                               'Select Excel time series Data sets','data.xlsx');
filePath = [chosendirectory chosenfile];
if filePath ~= 0 
    data.CompleteData = readtable(filePath); 
    data.DataHeder = data.CompleteData.Properties.VariableNames(1,:);
    data.inputdata = table2array(data.CompleteData(:,:));
    if size(data.inputdata,2)==1
        disp('Input data successfully read.');
        data.isDataRead = true;
    else
         warning('Input data should be an excel file with only one column!'); 
         disp('Operation Failed... '); pause(.9);
         disp('Reloading data. ');     pause(.9);
         readInputExcelFile;
         data.isDataRead = false;
    end
else 
    warning(['In order to train network, please load data.' ...
    'Input data should be an excel file with only one column!']);    
    disp('Operation Cancel.'); 
    data.isDataRead = false;
end
end
% Standardize input data and eliminate NaN
function data = dataPreparation(input,opt)
data.DataHeder = input.DataHeder;
data.Vars      = input.inputdata';
% data prepration
if iscell(data.Vars)
    for i=1:size(data.Vars,1)
        for j=1:size(data.Vars,2)
            if strcmpi(data.Vars{i,j},'#NULL!')
                tempVars(i,j) = NaN; %#ok
            else
                tempVars(i,j) = str2num(data.Vars{i,j});   %#ok
            end
        end
    end
    data.Vars = tempVars;
end
if opt.isNormilizeData
    for i=1:size(data.Vars,1)
        data.mu(1,i)   = mean(data.Vars(i,:),'omitnan');
        data.sig(1,i)  = std (data.Vars(i,:),'omitnan');
        data.Vars(i,:) = (data.Vars(i,:) - data.mu(1,i))./ data.sig(1,i);
    end

    % eliminate NaN with the mean value in any row
    for i=1:size(data.Vars,1)
        data.Vars(i,isnan(data.Vars(i,:))) = data.mu(i);
    end
end
end
% de-Normilizeing Data
function x = deNormilizeData(x,data)
x = x*data.sig+data.mu;
end
% partitioning input data 
function data = dataPartitioning(data,opt)
numTrSample = floor(opt.trPercentage*numel(data.Vars));
data.input.XTr   = data.Vars(1:numTrSample);
data.input.XTs   = data.Vars(numTrSample+1:end);
disp(['Time Series data divided to ' num2str(opt.trPercentage*100) '% Train data and ' num2str((1-opt.trPercentage)*100) '% Test data']);
end
% make some delays on input filed
function data = CreateTimeSeriesData(data, opt)
    if opt.isUseDelays
        Delays = opt.Delays;
    else
        Delays = [1];
    end
    
    x = data.input.XTr;
    data.input.XTs;
    T = size(x,2);
    
    MaxDelay = max(Delays);
    
    Range = MaxDelay+1:T;
    
    X= [];
    for d = Delays
        X=[X; x(:,Range-d)];
    end
    
    Y = x(:,Range);
    data.input.XTr = X;
    data.target.YTr = Y;
    
    
    
    x = data.input.XTs;    
    T = size(x,2);
    MaxDelay = max(Delays);
    Range = MaxDelay+1:T;
    X= [];
    for d = Delays
        X=[X; x(:,Range-d)];
    end
    Y = x(:,Range);
    data.input.XTs = X;
    data.target.YTs = Y;
    

end
% Prepare input data for FeedForward network.
function data = FeedForwardInput(data)
    data.XTr = data.input.XTr;  
    data.YTr = data.target.YTr;  

    data.XTs = data.input.XTs;  
    data.YTs = data.target.YTs; 
    disp('Time Series data prepared as suitable feedforward Input data.');
end
% Prepare input data for LSTM network.
function data = LSTMInput(data)
for i=1:size(data.input.XTr,2)
    data.XTr{i,1} = data.input.XTr(:,i);  
    data.YTr(i,1) = data.target.YTr(:,i);  
end

for i=1:size(data.input.XTs,2)
    data.XTs{i,1} = data.input.XTs(:,i);  
    data.YTs(i,1) = data.target.YTs(:,i); 
end
data.input = [];
data.target= [];
disp('Time Series data prepared as suitable LSTM Input data.');
end

% ---- network structure ----
% bi-LSTM Deeplearning Architect
function opt = LSTMArchitect(opt)

numHiddenUnits1 = opt.numHiddenUnits1;
numHiddenUnits2 = opt.numHiddenUnits2;
miniBatchSize  = opt.miniBatchSize;
maxEpochs      = opt.maxEpochs;
trainingProgress = opt.trainingProgress;
executionEnvironment = opt.executionEnvironment;
numResponses   = 1;
inputSize = size(opt.Delays,2);
opt.layers = [ ...
    sequenceInputLayer(inputSize)
    bilstmLayer(numHiddenUnits1,'OutputMode','sequence')
    bilstmLayer(numHiddenUnits2,'OutputMode','last')
    fullyConnectedLayer(numResponses)
    regressionLayer];

% Training Network Options
opt.opts = trainingOptions('adam', ...
    'MaxEpochs',maxEpochs, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',0.005, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',125, ...
    'LearnRateDropFactor',0.2, ...
    'Verbose',0, ...
    'MiniBatchSize',miniBatchSize,...
    'ExecutionEnvironment',executionEnvironment,...
    'Plots',trainingProgress);
    disp('LSTM architect successfully created.');

end
% FeedForward Shallowlearning Architect
function opt = FeedForwardArchitect(opt)
opt.Net = feedforwardnet(opt.ShallowhiddenLayerSize,opt.trainFcn);
opt.Net.divideParam.trainRatio = 0.7;
opt.Net.trainParam.epochs          = opt.maxItrations;
opt.Net.trainParam.showWindow      = opt.showWindow;
opt.Net.trainParam.showCommandLine = opt.showCommandLine;
disp('FeedForward architect successfully created.');

end
% Train  Network
function Net = TrainNet(data,opt)
if strcmpi(opt.learningMethod,'DeepLearning')
    Net = trainNetwork(data.XTr,data.YTr,opt.layers,opt.opts);
    disp('LSTM Netwwork successfully trained.');
elseif strcmpi(opt.learningMethod,'ShallowLearning')
    [Net,~] = train(opt.Net,data.XTr,data.YTr);
    disp('Feed Forward Netwwork successfully trained.');
end

end

% ---- assess bi-LSTM and FeedForward network -----
function results = evaluateNet(results,data,opt)
if strcmpi(opt.learningMethod,'DeepLearning')
    TrainOutputs = (predict(results.Net,data.XTr,'MiniBatchSize',opt.miniBatchSize));
    TrainTargets = data.YTr;
    TestOutputs  = (predict(results.Net,data.XTs,'MiniBatchSize',opt.miniBatchSize));
    TestTargets  = data.YTs;
    AllDataTargets = [TrainTargets;TestTargets];
    AllDataOutputs = [TrainOutputs;TestOutputs];
    disp('Bi-LSTM network performance evaluated.');
    
elseif strcmpi(opt.learningMethod,'ShallowLearning')
    TrainOutputs = results.Net(data.XTr);
    TrainTargets = data.YTr;
    TestOutputs  = results.Net(data.XTs);
    TestTargets  = data.YTs;
    AllDataTargets = [TrainTargets TestTargets];
    AllDataOutputs = [TrainOutputs TestOutputs];
    disp('Feedforward network performance evaluated.');
end
% denormilizing data
% if opt.isNormilizeData
%     TrainOutputs   = TrainOutputs,data);
%     TrainTargets   = deNormilizeData(TrainTargets,data);
%     TestOutputs    = deNormilizeData(TestOutputs,data);
%     TestTargets    = deNormilizeData(TestTargets,data);
%     AllDataTargets = deNormilizeData(AllDataTargets,data);
%     AllDataOutputs = deNormilizeData(AllDataOutputs,data);
% end
% Show Results
disp('Display results...');
figure;
PlotResults(TrainTargets, TrainOutputs, 'Train Data');

figure;
PlotResults(TestTargets, TestOutputs, 'Test Data');

figure;
PlotResults(AllDataTargets, AllDataOutputs, 'All Data');

if ~isempty(which('plotregression'))
    figure;
    plotregression(TrainTargets, TrainOutputs, 'Train Data', ...
                   TestTargets, TestOutputs, 'TestData', ...
                   AllDataTargets,AllDataOutputs, 'All Data');
end
results.TrainOutputs   = TrainOutputs;
results.TrainTargets   = TrainTargets;
results.TestOutputs    = TestOutputs;
results.TestTargets    = TestTargets;
results.AllDataTargets = AllDataTargets;
results.AllDataOutputs = AllDataOutputs;
end
% display results
function PlotResults(Targets, Outputs, Title)
    Errors = Targets - Outputs;
    MSE = mean(Errors.^2);
    RMSE = sqrt(MSE);
    ErrorMean = mean(Errors);
    ErrorStd = std(Errors);
    
    subplot(2,2,[1 2]);
    plot(Targets);
    hold on;
    plot(Outputs);
    legend('Targets','Outputs');
    ylabel('Targets and Outputs');
    grid on;
    title(Title);
    
    subplot(2,2,3);
    plot(Errors);
    title(['MSE = ' num2str(MSE) ', RMSE = ' num2str(RMSE)]);
    ylabel('Errors');
    grid on;
    
    subplot(2,2,4);
    histfit(Errors, 50);
    title(['Error Mean = ' num2str(ErrorMean) ', Error StD = ' num2str(ErrorStd)]);

end
